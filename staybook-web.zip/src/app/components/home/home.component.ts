import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { RequestService } from 'src/app/services/request.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  searchTerm: string = '';
  cities: any
  filteredCities:any = [];
  isDropdownOpen: boolean = false;
  searchForm:any 
  cityId:any 
  constructor(private formBuilder: FormBuilder , private req :RequestService , private router:Router) {
    this.searchForm = this.formBuilder.group({
      city: ['Karachi'],
      adults: [2],
      kids: [0],
      rooms: [1]
    });
  }
  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    this.req.post('city/list',true,true).subscribe((res:any)=>{
      this.cities = res.data
    })
  }
  filterCities() {
    this.filteredCities = this.cities.filter((city:any) => city.name.toLowerCase().includes(this.searchTerm.toLowerCase()));
  }
  selectCity(city:any) {
    this.searchTerm = city.name; // Set the selected city in the search input
    this.cityId = city.id; // Set the selected city in the search input
    this.filteredCities = [] // Hide the dropdown
  }
  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }
  increaseCount(type: string) {
    if (type === 'adults') {
      let adults = this.searchForm.value.adults
      adults++
      this.searchForm.get('adults').setValue(adults);
    } else if (type === 'kids') {
      let kids = this.searchForm.value.kids
      kids++
      this.searchForm.get('kids').setValue(kids);
    } else if (type === 'rooms') {
      let rooms = this.searchForm.value.rooms
      rooms++
      this.searchForm.get('rooms').setValue(rooms);
    }
  }
  decreaseCount(type: string) {
    if (type === 'adults') {
      let adults = this.searchForm.value.adults
      adults--
      this.searchForm.get('adults').setValue(adults);
    } else if (type === 'kids') {
      let kids = this.searchForm.value.kids
      kids--
      this.searchForm.get('kids').setValue(kids);
    } else if (type === 'rooms') {
      let rooms = this.searchForm.value.rooms
      rooms--
      this.searchForm.get('rooms').setValue(rooms);
    }
  }
  saveChanges() {
    this.isDropdownOpen = false;
  }
  onSubmit() {
    this.req.post('property/find', { city_id: this.cityId }, true).subscribe((res: any) => {
      console.log(res.data);
  
      // Navigate to the search-result component and pass the data
      this.router.navigate(['/search-result'], { queryParams: { data: JSON.stringify(res.data) , title:this.searchTerm} });

    });
  }
}
