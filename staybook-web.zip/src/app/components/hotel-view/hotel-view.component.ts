import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbCalendar, NgbDate } from '@ng-bootstrap/ng-bootstrap';
import { RequestService } from 'src/app/services/request.service';
import { trigger, state, style, animate, transition } from '@angular/animations';

@Component({
  selector: 'app-hotel-view',
  templateUrl: './hotel-view.component.html',
  styleUrls: ['./hotel-view.component.css'],
  animations: [
    trigger('popin', [
      state('true', style({ transform: 'scale(1)' })),
      state('false', style({ transform: 'scale(0)' })),
      transition('false => true', animate('1000ms ease-in')),
      transition('true => false', animate('1000ms ease-out'))
    ])
  ]
})
export class HotelViewComponent {
  hotelData: any;
  title:any
  isDropdownOpen:any
  searchForm:any
  hoveredDate: NgbDate | null = null;
  isHoveredOverCalendar:any = false
	fromDate: NgbDate;
	toDate: NgbDate | null = null;
  roomView:any = false


  constructor(private formBuilder: FormBuilder , private req :RequestService , private router:Router ,private calendar: NgbCalendar) {
    this.searchForm = this.formBuilder.group({
      city: ['Karachi'],
      adults: [2],
      kids: [0],
      rooms: [1]
    });
    this.fromDate = calendar.getToday();
		this.toDate = calendar.getNext(calendar.getToday(), 'd', 10);
  }

  
  ngOnInit() {
    this.hotelData = history.state.data;
    this.title = this.hotelData.name
  }
  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }
  increaseCount(type: string) {
    if (type === 'adults') {
      let adults = this.searchForm.value.adults
      adults++
      this.searchForm.get('adults').setValue(adults);
    } else if (type === 'kids') {
      let kids = this.searchForm.value.kids
      kids++
      this.searchForm.get('kids').setValue(kids);
    } else if (type === 'rooms') {
      let rooms = this.searchForm.value.rooms
      rooms++
      this.searchForm.get('rooms').setValue(rooms);
    }
  }
  decreaseCount(type: string) {
    if (type === 'adults') {
      let adults = this.searchForm.value.adults
      adults--
      this.searchForm.get('adults').setValue(adults);
    } else if (type === 'kids') {
      let kids = this.searchForm.value.kids
      kids--
      this.searchForm.get('kids').setValue(kids);
    } else if (type === 'rooms') {
      let rooms = this.searchForm.value.rooms
      rooms--
      this.searchForm.get('rooms').setValue(rooms);
    }
  }
  saveChanges() {
    this.isDropdownOpen = false;
  }

  

	onDateSelection(date: NgbDate) {
		if (!this.fromDate && !this.toDate) {
			this.fromDate = date;
		} else if (this.fromDate && !this.toDate && date.after(this.fromDate)) {
			this.toDate = date;
		} else {
			this.toDate = null;
			this.fromDate = date;
		}
	}

	isHovered(date: NgbDate) {
		return (
			this.fromDate && !this.toDate && this.hoveredDate && date.after(this.fromDate) && date.before(this.hoveredDate)
		);
	}

	isInside(date: NgbDate) {
		return this.toDate && date.after(this.fromDate) && date.before(this.toDate);
	}

	isRange(date: NgbDate) {
		return (
			date.equals(this.fromDate) ||
			(this.toDate && date.equals(this.toDate)) ||
			this.isInside(date) ||
			this.isHovered(date)
		);
	}
}
