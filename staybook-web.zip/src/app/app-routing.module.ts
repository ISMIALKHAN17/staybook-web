import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SearchResultComponent } from './components/search-result/search-result.component';
import { HomeComponent } from './components/home/home.component';
import { HotelViewComponent } from './components/hotel-view/hotel-view.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'search-result', component: SearchResultComponent },
  { path: 'hotel-view', component: HotelViewComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
  
}
